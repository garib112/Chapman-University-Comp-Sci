package megan.cards;

public enum Suit {
	HEARTS, SPADE, CLUBS, DIAMONDS
}
